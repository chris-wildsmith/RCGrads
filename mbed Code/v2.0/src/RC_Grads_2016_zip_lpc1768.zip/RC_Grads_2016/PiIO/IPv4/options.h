#ifndef IPV4OPTS_H
#define IPV4OPTS_H

#include "cc.h"

#define LWIP_CHKSUM_ALGORITHM   0

#endif /* IPV4OPTS_H */