//**********************************************************************************************************************
//   GRADUATE RAMPAGING CHARIOTS PI INTERFACE MESSAGE INITIALISATION - HEADER FILE
// *********************************************************************************************************************

#ifndef MESSAGE_INIT_H
#define MESSAGE_INIT_H

#include "PiIO.h"
#include "message_handlers.h"

//Forward declare PiIO.
class PiIO;
void pi_message_init(PiIO* interface);

#endif