//**********************************************************************************************************************
//   GRADUATE RAMPAGING CHARIOTS PI INTERFACE ENUMS - HEADER FILE
// *********************************************************************************************************************

#ifndef PIIO_ENUMS_H
#define PIIO_ENUMS_H

enum eCommsDir{IN, OUT};
//enum eMotion {motionF, motionB, motionL, motionR, motionS};

#endif
