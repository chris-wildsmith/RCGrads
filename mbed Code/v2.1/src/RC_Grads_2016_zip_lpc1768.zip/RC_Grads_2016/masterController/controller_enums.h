//**********************************************************************************************************************
//   GRADUATE RAMPAGING CHARIOTS CHARIOT CONTROLLER ENUMS - HEADER FILE
// *********************************************************************************************************************

#ifndef CONTROLLER_ENUMS_H
#define CONTROLLER_ENUMS_H

enum eMotion {FORWARDS, BACKWARDS, LEFT, RIGHT, STOP};

#endif
